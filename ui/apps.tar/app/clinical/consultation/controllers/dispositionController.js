'use strict';

angular.module('bahmni.clinical')
    .controller('DispositionController', ['messagingService', '$stateParams', 'visitFormService', '$rootScope', '$scope', '$http', '$q', '$location','$timeout', 'dispositionService', 'retrospectiveEntryService', 'spinner','visitService','locationService','appService', '$bahmniCookieStore', function (messagingService, $stateParams, visitFormService, $rootScope, $scope, $http, $q, $location, $timeout, dispositionService, retrospectiveEntryService, spinner,visitService,locationService,appService,$bahmniCookieStore) {
        var consultation = $scope.consultation;
        var allDispositions = [];
        var wards= $http.get("/openmrs/ws/rest/v1/admissionLocation/");
        var encounterConfig = $rootScope.encounterConfig;
        var emergencyLocationNames = appService.getAppDescriptor().getExtensions("org.bahmni.clinical.emergencyLocation.names","erLoc");
        $scope.procedures = []
        $scope.isVIP = false;
        
        var currentLocation = $bahmniCookieStore.get(Bahmni.Common.Constants.locationCookieName);
        var locations = emergencyLocationNames[0].Locations;
    
        locationService.getLoggedInLocation().then(function (loggedInLocation) {
            var parentLocation = loggedInLocation.parentLocation;
            currentLocation = loggedInLocation;
            
            if (locations.hasOwnProperty(parentLocation.display)) {
                locationService.getByUuid(parentLocation.uuid).then(function (parentLocation) {
                    currentLocation = parentLocation;
                    $scope.isEmergencyLocation = emergencyLocationNames.length > 0 && locations.hasOwnProperty(currentLocation.name);
                    
                    if ($scope.isEmergencyLocation) {
                        $scope.visitType = currentLocation.childLocations.filter((cld) => {
                            return cld.display !== $scope.$parent.activeVisit.visitType.display;
                        });
                    }
                });
            } else {
                $scope.isEmergencyLocation = emergencyLocationNames.length > 0 && locations.hasOwnProperty(currentLocation.name);
                
                if ($scope.isEmergencyLocation) {
                  
                    $scope.visitType = currentLocation.childLocations.filter((cld) => { 
                        return cld.display !== $scope.$parent.activeVisit.visitType.display;
                    });
                }
             
            }
            
            spinner.forPromise(loadDispositionActions(), '#disposition');
        }).catch(function (error) {
            console.error("Error fetching location:", error);
        });
        $scope.wards = [];
        $scope.bedServices = [];
        var loadAllWards = function () {
            return wards.success(function (wardsList) {
                    $scope.wards = wardsList.results;
            });
        };
        var getBedServices = function () {
            var params = {
                q: "bahmni.sqlGet.getBedServices"
            };
            return $http.get('/openmrs/ws/rest/v1/bahmnicore/sql', {
                method: "GET",
                params: params,
                withCredentials: true
            });
        };
        loadAllWards();
        $scope.patientIsDecalredDead = false;
        $scope.patientHasDiagnosis = false;

        $scope.patientHasReferralForm = false;

        // Check if the referral form is filled
        visitFormService.formData($scope.patient.uuid, 1, ["Referral Form"]).then(function (res) {
            console.log("Referral Form Data:", res.data.results); // Debugging
            $scope.patientHasReferralForm = res.data.results.length > 0;
        }).catch(function (error) {
            console.error("Error fetching referral form data:", error);
        });
        visitFormService.formData($scope.patient.uuid, 1, ["Death Notification"]).then(function (res){
            $scope.patientIsDecalredDead = res.data.results.length > 0;
        })
        // get list of diagnosis and check if there is a main diagnosis
        visitFormService.formData($scope.patient.uuid, 1, ["Coded Diagnosis"], undefined, "full").then(function (res){
            res.data.results.forEach(diagnosis => {
                if (diagnosis.obsGroup.comment === "~Main") {
                    $scope.patientHasDiagnosis = true;
                }
            });
        })
        getBedServices().then(function(r){
            $scope.bedServices = r.data;
        });

        
        //For redirection from ER triage visit
        var triageScoreResult =$location.search()['TriageScoreResult'];
        var triageColorResult =$location.search()['TriageColorResult'];
        var firstGo = 0;        
        var setNotes = function(){
            if(!angular.isUndefined(triageScoreResult)){
                var unregister = $scope.$watch('dispositionCode', function () {
                    $scope.dispositionCode = "KEEP_PATIENT";
                    firstGo++;
                    if(firstGo==4){unregister();}
                    
                });
                var unregister2 = $scope.$watch('dispositionNote', function () {
                    if($scope.dispositionNote!=undefined){
                    $scope.dispositionNote.value = 'Triage Score Result is ' + triageScoreResult + ' And Triage Color Result is ' + triageColorResult;
                    unregister2();}
                });
            }
        }

        setNotes();
        
        var getPreviousDispositionNote = function () {
            if (consultation.disposition && (!consultation.disposition.voided)) {
                return _.find(consultation.disposition.additionalObs, function (obs) {
                    return obs.concept.uuid === $scope.dispositionNoteConceptUuid;
                });
            }
        };

        var getDispositionNotes = function () {
            var previousDispositionNotes = getPreviousDispositionNote();
            if (getSelectedConceptName($scope.dispositionCode, $scope.dispositionActions)) {
                return _.cloneDeep(previousDispositionNotes) || {concept: {uuid: $scope.dispositionNoteConceptUuid}};
            }
            else {
                return {concept: {uuid: $scope.dispositionNoteConceptUuid}};
            }
        };

        var getDispositionActionsPromise = function () {
            return dispositionService.getDispositionActions().then(function (response) {
                allDispositions = new Bahmni.Clinical.DispostionActionMapper().map(response.data.results[0].answers);
                $scope.dispositionActions = filterDispositionActions(allDispositions, $scope.$parent.visitSummary);
                $scope.dispositionCode = consultation.disposition && (!consultation.disposition.voided) ? consultation.disposition.code : null;
                $scope.dispositionNote = getDispositionNotes();
            });
        };

        var getDispositionActions = function (finalDispositionActions, dispositions, action) {
            var copyOfFinalDispositionActions = _.cloneDeep(finalDispositionActions);
            var dispositionPresent = _.find(dispositions, action);
            if (dispositionPresent) {
                copyOfFinalDispositionActions.push(dispositionPresent);
            }
            if (!$scope.isEmergencyLocation) {
                copyOfFinalDispositionActions = copyOfFinalDispositionActions.filter(cpy => {
                    return cpy.code !== "MOVE_ER" &&
                           (cpy.code !== "UnKeep") &&
                           (cpy.code !== "KEEP");
                });
            } 
            return copyOfFinalDispositionActions;
        };

        var filterDispositionActions = function (dispositions, visitSummary) {
            if (!consultation.dispositions) {
                consultation.dispositions = [];
            }
            // Fetch previous dispositions if not already available
            if (consultation.dispositions.length === 0 && consultation.disposition) {
                consultation.dispositions.push(consultation.disposition);
            }
            var isPatientKept = consultation.dispositions.some(function (d) {
                return d.code === "KEEP";
            });
            var defaultDispositions = ["Undo Discharge", "Admit Patient", "Transfer Patient", "Discharge Patient"];
            var finalDispositionActions = _.filter(dispositions, function (disposition) {
                return defaultDispositions.indexOf(disposition.name) < 0;
            });
            finalDispositionActions = finalDispositionActions.filter(function (action) {
                if (action.code === "KEEP") {
                    return !isPatientKept;
                } else if (action.code === "UnKeep") {
                    return isPatientKept;
                }
                return true; // Keep other dispositions

            });
            var isVisitOpen = visitSummary ? _.isEmpty(visitSummary.stopDateTime) : false;
            if (visitSummary && visitSummary.isDischarged() && isVisitOpen) {
                finalDispositionActions = getDispositionActions(finalDispositionActions, dispositions, { name: defaultDispositions[0]});
            }
            else if (visitSummary && visitSummary.isAdmitted() && isVisitOpen) {
                finalDispositionActions = getDispositionActions(finalDispositionActions, dispositions, { name: defaultDispositions[2]});
                finalDispositionActions = getDispositionActions(finalDispositionActions, dispositions, { name: defaultDispositions[3]});
            }
            else {
                finalDispositionActions = getDispositionActions(finalDispositionActions, dispositions, { name: defaultDispositions[1]});
            }
            return finalDispositionActions;
        };

        $scope.isRetrospectiveMode = function () {
            return !_.isEmpty(retrospectiveEntryService.getRetrospectiveEntry());
        };

        $scope.showWarningForEarlierDispositionNote = function () {
            return !$scope.dispositionCode && consultation.disposition;
        };

        var getDispositionNotePromise = function () {
            return dispositionService.getDispositionNoteConcept().then(function (response) {
                $scope.dispositionNoteConceptUuid = response.data.results[0].uuid;
            });
        };

        var loadDispositionActions = function () {
            return getDispositionNotePromise().then(getDispositionActionsPromise);
        };

        $scope.clearDispositionNote = function () {
            $scope.dispositionNote.value = null;
            //check if the disposition is something specific and  if the patient does not have main diagnosis, redirect
            $rootScope.deadToSave = false;
            let smallDisposition = $scope.dispositionCode ? $scope.dispositionCode.toLowerCase() : "";
            let dispositionIsDead = smallDisposition.includes("dead");
            let dispositionIsRefer = smallDisposition.includes("refer");
            let listOfDispositions = ["dead", "refer", "discharge", "send"]
            let dispositionIsx = false;
            listOfDispositions.forEach(element => {
                if (smallDisposition.includes(element)){
                    dispositionIsx = true;
                }
            });
            if (dispositionIsx) {
                if ($scope.patientHasDiagnosis) {
                    //fill with things that need to be done if main diagnosis is filled
                    if (dispositionIsDead) {
                        if ($scope.patientIsDecalredDead) {
                            //put something in rootscope to modify the save
                            $rootScope.deadToSave = true;
                        }
                        else {
                            $scope.dispositionCode = undefined;
                            $rootScope.reqDeathNotification = true;
                            messagingService.showMessage("error", "The Death Notification Form needs to be filled first. Please fill it out now and save it before proceeding to fill the disposition");
                            $location.path($location.path().replace("disposition", "concept-set-group/observations"));
                        }
                    }
                }
                else {
                    $scope.dispositionCode = undefined;
                    messagingService.showMessage("error", "The Main Diagnosis has to be filled out before taking this action. Please fill it out now and save it before proceeding to fill the disposition");
                    $location.path($location.path().replace("disposition", "diagnosis"));
                }

                if (dispositionIsRefer) {
                    if ($scope.patientHasReferralForm) {
                        // Allow the referral action
                    } else {
                        $scope.dispositionCode = undefined;
                        messagingService.showMessage("error", "The Referral Form needs to be filled first. Please fill it out now and save it before proceeding to refer the patient.");
                        $location.path(`/default/patient/${$scope.patient.uuid}/dashboard/concept-set-group/observations`);
                    }
                }
            }
        };

        var getSelectedConceptName = function (dispositionCode, dispositions) {
            var selectedDispositionConceptName = _.findLast(dispositions, {code: dispositionCode}) || {};
            return selectedDispositionConceptName.name;
        };

        var getSelectedDisposition = function () {
            if ($scope.dispositionCode) {
                $scope.dispositionNote.voided = !$scope.dispositionNote.value;
                var disposition = {
                    additionalObs: [],
                    dispositionDateTime: consultation.disposition && consultation.disposition.dispositionDateTime,
                    code: $scope.dispositionCode,
                    conceptName: getSelectedConceptName($scope.dispositionCode, allDispositions)
                };
                if ($scope.dispositionNote.value || $scope.dispositionNote.uuid) {
                    disposition.additionalObs = [_.clone($scope.dispositionNote)];
                }
                return disposition;
            }
        };

        //spinner.forPromise(loadDispositionActions(), '#disposition');

        var getAvailableBedServiceOrder = function () {
            return _.filter($scope.consultation.orders, function (order) {
                return order.orderType == "Bed Service";
            }); 
        };
        var discontinueBedServices = function (bedServices) {
            for(let i = 0; i < bedServices.length; i++) {
                bedServices[i].isDiscontinued = true;
            }
        }

        var saveDispositions = function () {
            if($scope.selectedWard!= undefined && $scope.dispositionCode=='ADMIT'){
                var prevAdmitCheck;
                var selectedBedService;
                var bedServiceOrder;
                if($scope.dispositionNote.value){
                    prevAdmitCheck = $scope.dispositionNote.value.split(": ");
                    if(prevAdmitCheck.length == 2){
                        $scope.dispositionNote.value=prevAdmitCheck[0]+ ": " + $scope.selectedWard;
                    }
                    else{
                        $scope.dispositionNote.value= $scope.dispositionNote.value+"\nPatient Sent to: "+ $scope.selectedWard;
                    }
                }
                else{
                    $scope.dispositionNote.value="Patient Sent to: "+ $scope.selectedWard;
                }
                selectedBedService = _.find($scope.bedServices, function (bedService) {

                    return $scope.selectedWard.toLowerCase() == bedService.name.toLowerCase();

                });
                if(selectedBedService) {
                    bedServiceOrder = {concept: selectedBedService, commentToFulfiller: "", urgency: "ROUTINE"};
                    var availableBedServiceOrders = getAvailableBedServiceOrder();
                    var alreadyExistsBedService =  _.find(availableBedServiceOrders, function(bedService) {
                        return bedService.concept.name.toLowerCase() ==  $scope.selectedWard.toLowerCase();
                    })
                    if(!alreadyExistsBedService) {
                        if(availableBedServiceOrders && availableBedServiceOrders.length > 0) {
                            discontinueBedServices(availableBedServiceOrders);
                        } 
                            $scope.consultation.orders.push(bedServiceOrder);
                    }
                }
                
            }
                
            if($scope.selectedTransferWard !== undefined && $scope.dispositionCode === 'TRANSFER'){
                
                var prevAdmitCheck;
                if($scope.dispositionNote.value){
                    prevAdmitCheck = $scope.dispositionNote.value.split(": ");
                    if(prevAdmitCheck.length == 2){
                        $scope.dispositionNote.value=prevAdmitCheck[0]+ ": " + $scope.selectedTransferWard;
                    }
                    else {
                        $scope.dispositionNote.value = $scope.dispositionNote.value + "\nPatient Transferred to: " + $scope.selectedTransferWard;
                      }
                }
                else {
                    $scope.dispositionNote.value = "Patient Transferred to: " + $scope.selectedTransferWard;
                }
            }
            
            var selectedDisposition = getSelectedDisposition();
            if (selectedDisposition) {
                consultation.disposition = selectedDisposition;
            } else {
                if (consultation.disposition) {
                    consultation.disposition.voided = true;
                    consultation.disposition.voidReason = "Cancelled during encounter";
                }
            }
        };
    
        var getCurrLoceUuid = function (vUuid) {
            var params = {
                q: "bahmni.sqlGet.currLocVisitAttribute",
                vUuid: vUuid
            };
            return $http.get('/openmrs/ws/rest/v1/bahmnicore/sql', {
                method: "GET",
                params: params,
                withCredentials: true
            });
        };
        $scope.link = function(selectedVisitType){
            var selectedVisit= _.filter($scope.visitType, function (visitType) {
                return visitType.display === selectedVisitType;
            });
            if(selectedVisit.length > 0) {
                getCurrLoceUuid($scope.$parent.activeVisit.uuid).then(function(r){
                    var attributes = {attributes: [{value :selectedVisit[0].uuid, attributeType:r.data[0].uuid}]}; 
                    visitService.updateLocation($scope.$parent.activeVisit.uuid, attributes).then(function (response) {
                        messagingService.showMessage('info', 'Moved Patient Successful');
                    });
                })
            }
        }

        $scope.consultation.preSaveHandler.register("dispositionSaveHandlerKey", saveDispositions);
        $scope.$on('$destroy', saveDispositions);
       

    }])
    