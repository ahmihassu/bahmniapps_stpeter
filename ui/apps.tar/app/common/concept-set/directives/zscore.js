'use strict';

angular.module('bahmni.common.conceptSet')
    .directive('zscore', ['appService', '$http', function (appService, $http) {
        return {
            restrict: 'E',
            scope: {
                observation: '=',
                abnormalObs: '=?',
                patient:'='
            },

            link: function (scope, element, attrs) {
                if (attrs.dirtyCheckFlag) {
                    scope.hasDirtyFlag = true;
                }
            },
            controller: function ($scope) {
                $scope.inner_value
                $scope.catagories = [
                    {name: "BMI Z-Score", value: "bmi", unit: "", ent_name: "BMI", sec_unit: "CM", sec_name: "Height", thir_unit: "KG", thir_name: "Weight"},
                    {name:"Head Circumference Z-Score", value: "hcfa", unit: "CM", ent_name: "Head Circumference"},
                    {name:"Length Height For Age Z-Score", value: "lhfa", unit: "CM", ent_name: "length/height"},
                    {name:"Weight for Age Z-Score", value: "wfa", unit: "KG", ent_name: "Weight"}, 
                    {name:"Weight for Height Z-Score", value: "wfl", unit: "KG", ent_name: "Weight", sec_unit: "CM", sec_name: "Height"}
                ];
            
                var load = function () {
                    return appService.loadConfig('z_score.json').then(res => {
                        $scope.lookup = res
                    })
                };
                var calculateBMI = function(hei, wei){
                    var height = hei/100
                    var bmi_score = (wei / (height*height)).toFixed(2);
                    return bmi_score
                }
                var formData = function (patientUuid) {
                    var params = {
                        s: "byPatientUuid",
                        patient: patientUuid,
                        numberOfVisits: 1,
                        v: "visitFormDetails",
                        conceptNames: ["BMI"],
                        patientProgramUuid: null
                    };
                    return $http.get(Bahmni.Common.Constants.formDataUrl, {params: params});
                };
                $scope.initz = function(){
                    // Set actSelected based on observation.concept.name
                    var conceptName = ($scope.observation.concept.name || '');
                    $scope.actSelected = $scope.catagories.find(function(cat) {
                        return (cat.name || '') === conceptName;
                    });
                    $scope.inner_value = undefined;
                    $scope.sec_value = undefined;
                    $scope.thir_value = undefined;
                    load();
                    formData($scope.patient.uuid).then(res => {
                        $scope.bmi = res.data
                    })
                }
                $scope.showlookup = function(){
                    var gender = "boys"
                    var one_week = 1000 * 60 * 60 * 24 * 7
                    var one_month = 1000 * 60 * 60 * 24 * 30 
                    var date1 = new Date($scope.patient.birthdate)
                    var date2 = new Date()
                    var weeks = Math.floor((date2.getTime() - date1.getTime())/one_week);
                    var months = Math.floor((date2.getTime() - date1.getTime())/one_month);
                    if($scope.patient.gender == "F"){
                        gender = "girls"
                    } 
                    var filtered_sheet = Object.keys($scope.lookup).filter(excl_sheet => {
                        return excl_sheet.includes($scope.actSelected.value) && excl_sheet.includes(gender) 
                    })
                    var sec_filt = []
                    var ind
                    if(weeks <= 13){
                        sec_filt = filtered_sheet.filter(excl_sheet => {
                            return excl_sheet.includes("13")
                        })
                        ind = weeks
                    }
                    if(sec_filt.length == 0 && months <= 24){
                        sec_filt = filtered_sheet.filter(excl_sheet => {
                            return excl_sheet.includes("2") && excl_sheet.includes("0")
                        })
                        ind = months
                    }
                    if(sec_filt.length == 0 && months <= 60){
                        sec_filt = filtered_sheet.filter(excl_sheet => {
                            return excl_sheet.includes("5")
                        })
                        ind = months
                    }
                    if(sec_filt.length != 0){
                        if($scope.actSelected.thir_name){
                            $scope.inner_value = Number(calculateBMI($scope.sec_value, $scope.thir_value))
                        }  
                        else if($scope.actSelected.sec_name){
                            ind = $scope.sec_value
                        }
                        
                        var target_row = $scope.lookup[sec_filt[0]][ind.toString()]
                        var L = target_row[0]
                        var M = target_row[1]
                        var S = target_row[2]
                        $scope.observation.value = (0 + (((($scope.inner_value/M)**L) - 1)/ (L*S))).toString()
                        $scope.observation.comment = $scope.selectedType
                        console.log($scope.selectedType)
                    }
                }
            },
            templateUrl: '../common/concept-set/views/observationDataTypes/zscore.html'
        };
    }]);
