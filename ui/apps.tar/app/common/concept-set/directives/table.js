'use strict';

angular.module('bahmni.common.conceptSet')
    .directive('tab', ['appService', '$http', 'conceptSetService', '$rootScope', 'spinner','observationsService','$stateParams', function (appService, $http, conceptSetService, $rootScope, spinner,observationsService,$stateParams) {
        return {
            restrict: 'E',
            scope: {
                observation: '=',
                rootObs: '=',
                patient: '=',
                fixed: '=?'
            },
            link: function (scope, element, attrs) {
                if (attrs.dirtyCheckFlag) {
                    scope.hasDirtyFlag = true;
                }
            },
            controller: function ($scope) {
                $scope.datesOfObs = [];
                $scope.conceptElements = [];
                $scope.rootObs = !$scope.rootObs ? $scope.observation : $scope.rootObs
                var customRep = "custom:(obsDatetime,obsGroup,uuid,value,groupMembers,display,concept:(display,conceptClass))"
                var customRepForm = "custom:(groupMembers:(uuid),concept:(name:(name)))"

                var destructureObs = function (obs, arr) {

                    if (obs.groupMembers.length > 0) {
                        _.forEach(obs.groupMembers, function (member) {
                            if(!member.hidden)
                            arr.push(member)
                            if (member.concept.conceptClass != "Concept Details" && $scope.observation.concept.name != "VMT")
                                destructureObs(member, arr)
                        })
                    }
                }
                var constructDateColumn = function (member) {
                    var dateTime = new Date(member?.obsDatetime  || member?.observationDateTime).toLocaleDateString() + " " + new Date(member?.obsDatetime  || member?.observationDateTime).toLocaleTimeString();
                    if (!$scope.datesOfObs.includes(dateTime)) {
                        $scope.datesOfObs.push(dateTime)
                    }
                }

                var sortDate = function (arr) {
                    arr.sort(function (a, b) {
                        const dateA = new Date(a);
                        const dateB = new Date(b);
                        return dateB - dateA
                    })
                }

                var setPreviousValues = function (results, observation) {
                    observation.prevValues = []
                    if (results && results.length > 0) {
                        _.forEach(results, function (result) {
                            constructDateColumn(result)

                            if (!observation.isObservationNode && observation.concept.conceptClass != "Concept Details") {
                                observation.prevValues.push({
                                    obsDate: (new Date(result?.obsDatetime  || result?.observationDateTime)).toLocaleDateString() + " " + new Date(result?.obsDatetime || result?.observationDateTime).toLocaleTimeString(),
                                    value: result.value && (typeof result.value === 'object') ? result.value.display : result.value,
                                    name: result.concept.display
                                })
                                if(result.obsGroup.concept.display == 'VMT'){
                                    _.forEach(result.groupMembers,function(result){
                                        _.forEach(observation.groupMembers, function(member){
                                            if(member.concept.name ==result.concept.display){
                                                if(!member.prevValues)
                                                    member.prevValues = [];

                                                member.prevValues.push({
                                                    obsDate: (new Date(result?.obsDatetime  || result?.observationDateTime)).toLocaleDateString() + " " + new Date(result?.obsDatetime  || result?.observationDateTime).toLocaleTimeString(),
                                                    value: result.value,
                                                    name: result.concept.display
                                                })
                                            }
                                            })

                                        })
                                        }
                                    }
                            if (observation.concept.conceptClass == "Concept Details") {
                                if($scope.fixed){
                                    var val = result.value
                                    var abn = result.isAbnormal
                                }
                                else{
                                var val = result.display ? result.display.split(':')[1] : ""
                                var abn = val?.match(/[a-zA-Z]+/g)[0]
                                }
                                observation.prevValues.push({
                                    obsDate: (new Date(result?.obsDatetime  || result?.observationDateTime)).toLocaleDateString() + " " + new Date(result?.obsDatetime  || result?.observationDateTime).toLocaleTimeString(),
                                    value: $scope.fixed ? result.value : val.match(/\d+(\.\d+)?/g)[0],
                                    isAbnormal: String(abn) == "true" ? { 'color': 'red' } : { 'color': 'black' },
                                    name: result.concept.display,
                                })
                            }
                        })
                    }

                    sortDate($scope.datesOfObs)
                }

                var fetchData = function (patientUuid, formGroup, customRepresentation,visitUuid) {
                    if (!$scope.fixed) {
                    var params = {
                        patient: patientUuid,
                        limit: 50,
                        numberOfVisits: 1,
                        v: customRepresentation,
                        conceptNames: formGroup
                    };
                    return $http.get(Bahmni.Common.Constants.openmrsObsUrl, { params: params });
                }
                if($scope.fixed){
                    return observationsService.fetch(patientUuid, formGroup, null, 1, visitUuid ,null, null).then(function (response) {
                            return response.data; 
                        })
                }
            }

                var getFormData = function (observations) {

                    var isFormTab = $scope.observation.concept.name == $scope.rootObs.concept.name
                    var visitUuid = $stateParams.visitUuid
                     var conceptName = isFormTab ? $scope.observation.concept.name : $scope.rootObs.concept.name
                     var representation = isFormTab ? customRep : customRepForm

                     spinner.forPromise(fetchData($scope.patient.uuid, conceptName, representation,visitUuid).then(function (res) {
                        var rootResults = res?.data?.results || res

                        if(!isFormTab){
                            rootResults = rootResults.flatMap(function(rootResult){
                                return rootResult.groupMembers
                            })
                            }
                        else{
                            rootResults = rootResults.filter(function(rootResult){
                                var obsGroup = rootResult?.obsGroup || rootResult?.obsGroupUuid
                                if(!obsGroup)
                                    return rootResult
                            })
                            }

                    _.forEach(observations, function (observation) {

                        spinner.forPromise(fetchData($scope.patient.uuid, observation.concept.name, customRep, visitUuid).then(function (res) {
                            var results = res?.data?.results || res
                            results = results.filter(function(result){
                                return rootResults.some(function(rootResult){
                                    return rootResult.uuid == (result?.obsGroup?.uuid || result.obsGroupUuid)
                                })
                            })
                            
                            setPreviousValues(results, observation)
                        }));
                    })
                }));
            }

                var isObsCloned = function () {
                    var members = $scope.observation.groupMembers
                    if (members[0] && members[1]) {
                        return members[0].concept.uuid == members[1].concept.uuid
                    }
                    else
                        return false
                }

                var cloneNew = function (observation, parentObservation) {
                    var newObs = observation.cloneNew();
                    parentObservation.groupMembers.push(newObs)
                    $scope.$root.$broadcast("event:addMore", newObs);
                };

                $scope.resetConcept = function () {
                    $scope.conceptElements = []
                    var groupMembers = angular.copy($scope.observation.groupMembers)

                    $scope.observation.groupMembers = []

                    _.forEach(groupMembers, function (member) {
                        cloneNew(member, $scope.observation)
                    })

                    destructureObs($scope.observation, $scope.conceptElements)
                    getFormData($scope.conceptElements)

                }

                if (!$scope.fixed) {
                    if (isObsCloned()) {
                        $scope.observation.groupMembers = _.filter($scope.observation.groupMembers, function (member, idx, arr) {
                            if (arr[idx + 1]) {
                                if (member.concept.uuid != arr[idx + 1].concept.uuid)
                                    return member
                            }
                            else
                                return member
                        })
                    }

                    destructureObs($scope.observation, $scope.conceptElements)
                    getFormData($scope.conceptElements)

                }
                if ($scope.fixed) {
                    conceptSetService.getConcept({ name: $scope.observation.concept.name, v: "bahmni" }).then(function (response) {
                        var concept = response.data.results[0]
                        var observationMapper = new Bahmni.ConceptSet.ObservationMapper();
                        var obs = observationMapper.map([], concept, null)
        
                        destructureObs(obs, $scope.conceptElements)
                        getFormData($scope.conceptElements)
                    });
                }

            },
            templateUrl: '../common/concept-set/views/observationDataTypes/table.html'
        }
    }
    ])