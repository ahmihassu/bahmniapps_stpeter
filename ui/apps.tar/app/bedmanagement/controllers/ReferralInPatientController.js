"use strict";

angular.module('ipd')
    .controller('ReferralInPatientController', ['$scope', '$q', '$rootScope', '$state',
        'encounterService', 'conceptSetService', 'sessionService',
        'messagingService', '$stateParams', 'ngDialog', '$http',
        function ($scope, $q, $rootScope, $state, encounterService, conceptSetService, sessionService,
            messagingService, $stateParams, ngDialog, $http) {

            $scope.patientUuid = $stateParams.patientUuid;
            var locationUuid = sessionService.getLoginLocationUuid();
            var observationMapper = new Bahmni.ConceptSet.ObservationMapper();

            $scope.referral = {}; // Initialize display data object
            $scope.referralInputObservations = {}; // Initialize object to hold observations for potential inputs

            // Define concepts needed for potential input fields AND their corresponding keys
            var conceptsNeededForInput = [
                { key: 'diagnosis', name: 'Patient diagnosis' },
                { key: 'fromLocation', name: 'Referral from' },
                { key: 'referralReason', name: 'Triage Referral reason' },
                { key: 'triageCommunication', name: 'Triage Communication' },
                { key: 'timeOfCommunication', name: 'Time of communication' },
                { key: 'timeOfArrival', name: 'Time of arrival' },
                { key: 'referringPhysician', name: 'Name of Physician who referred the patient' }
            ];

            // --- Function to fetch existing referral data from SQL query ---
            var fetchReferralData = function () {
                var params = {
                    q: 'bahmni.sqlGet.patientsReferralInData',
                    patientUuid: $stateParams.patientUuid,
                    v: 'full'
                };

                // Initialize referral object cleanly before fetch
                $scope.referral = {};

                return $http.get(Bahmni.Common.Constants.sqlUrl, {
                    params: params,
                    withCredentials: true
                }).then(function (response) {
                    console.log("API Response for referral data:", response.data);
                    if (response.data && response.data.length > 0) {
                        const referralData = response.data[0];
                        console.log("Raw Referral Data from SQL:", referralData);
                        // Map SQL results to $scope.referral, checking for null/undefined
                        $scope.referral = {
                            // Use || null to ensure properties exist but are null if DB returns null
                            patientDiagnosis: referralData["Patient diagnosis"],
                            fromLocation: referralData["Referred from"],
                            referralReason: referralData["Referral reason"],
                            triageCommunication: referralData["Triage Communication"],
                            timeOfCommunication: referralData["Time of communication"],
                            timeOfArrival: referralData["Time of arrival"],
                            referringPhysician: referralData["Name of physician who referred"]
                        };
                        console.log("Formatted $scope.referral:", $scope.referral);
                    } else {
                        console.warn("No referral data found via SQL for patientUuid:", $stateParams.patientUuid);
                        // Explicitly set all expected keys to null if no data row found
                        // This ensures the ng-if conditions in the HTML work correctly
                        $scope.referral = {
                            patientDiagnosis: null,
                            fromLocation: null,
                            referralReason: null,
                            triageCommunication: null,
                            timeOfCommunication: null,
                            timeOfArrival: null,
                            referringPhysician: null
                        };
                    }
                }).catch(function (error) {
                    messagingService.showMessage('error', 'Failed to fetch referral data');
                    console.error("Error fetching referral data via SQL:", error);
                    // Set keys to null on error as well, so inputs might show
                    $scope.referral = {
                        patientDiagnosis: null,
                        fromLocation: null,
                        referralReason: null,
                        triageCommunication: null,
                        timeOfCommunication: null,
                        timeOfArrival: null,
                        referringPhysician: null
                    };
                });
            };

            // --- Function to initialize concept sets needed for potential input ---
            var initializeConceptInputs = function () {
                var conceptPromises = conceptsNeededForInput.map(function (conceptInfo) {
                    return conceptSetService.getConcept({
                        name: conceptInfo.name,
                        // Requesting specific fields needed by observationMapper and concept-set directive
                        v: "custom:(uuid,name,datatype:(uuid,name),conceptClass:(uuid,name),setMembers:(uuid,name,datatype:(uuid,name),conceptClass:(uuid,name),answers:(uuid,name,displayString)),answers:(uuid,name,displayString))"
                    }).then(function (response) {
                        if (response.data.results && response.data.results.length > 0) {
                            var concept = response.data.results[0];
                            // Create a placeholder observation structure for this concept
                            var observation = observationMapper.map([], concept, []); // Pass empty existing obs
                            // Store it as an array, as concept-set directive expects 'observations' array
                            $scope.referralInputObservations[conceptInfo.key] = [observation];
                            console.log("Initialized input observation structure for:", conceptInfo.key);
                        } else {
                            console.error("Concept not found:", conceptInfo.name);
                            messagingService.showMessage('error', 'Configuration error: Concept not found - ' + conceptInfo.name);
                            // Set the corresponding input key to null or empty array to prevent errors in view
                            $scope.referralInputObservations[conceptInfo.key] = [];
                            return $q.reject("Concept not found: " + conceptInfo.name);
                        }
                    }).catch(function (conceptError) {
                        console.error("Error fetching concept details for:", conceptInfo.name, conceptError);
                        $scope.referralInputObservations[conceptInfo.key] = []; // Ensure it's empty on error
                        // Don't necessarily reject the whole $q.all, allow others to load
                        // return $q.reject(...) // Optional: uncomment to make entire init fail on one concept error
                    });
                });

                // Wait for all concept fetches to complete
                return $q.all(conceptPromises).then(function () {
                    console.log("All concept input structures initialized.");
                }).catch(function (error) {
                    console.error("Error initializing one or more concept input structures:", error);
                    // Handle case where some concepts might fail to load, maybe show broader error
                });
            };

            //to prepare encounter data
            var getEncounterData = function () {
                var encounterData = {};
                encounterData.patientUuid = $scope.patientUuid;
                encounterData.encounterTypeUuid = $rootScope.encounterConfig.getRegistrationEncounterTypeUuid();
                encounterData.observations = _.filter($scope.observations, function (observation) {
                    return !_.isEmpty(observation.value);
                });
                encounterData.locationUuid = locationUuid;
                return encounterData;
            };

            // --- Save function ---
            $scope.saveReferralData = function () {
                console.log("Save clicked. Current input observations:", $scope.referralInputObservations);

                var encounterData = getEncounterData();
                // Ensure we have a valid encounter structure before proceeding
                if (!encounterData || !encounterData.encounterTypeUuid) {
                    console.error("Cannot save: Encounter data structure is invalid or missing Encounter Type UUID.");
                    return;
                }

                var observationsToSave = [];
                // Mapping of referral input keys to the corresponding referral data attributes
                var referralFieldsMapping = {
                    diagnosis: 'Patient Diagnosis',
                    fromLocation: 'fromLocation',
                    referralReason: 'referralReason',
                    triageCommunication: 'triageCommunication',
                    timeOfCommunication: 'timeOfCommunication',
                    timeOfArrival: 'timeOfArrival',
                    referringPhysician: 'referringPhysician'
                };

                // Iterate through the input observation structures
                angular.forEach($scope.referralInputObservations, function (obsArray, key) {
                    // Skip saving if the referral already has a value for this attribute
                    console.log(key, "->", referralFieldsMapping[key]);
                    if ($scope.referral && $scope.referral[referralFieldsMapping[key]]) {
                        console.log("Skipping saving for", key, "as an existing referral value is present.");
                        return;
                    }
                    // Check if the array and the first observation exist
                    if (obsArray && obsArray.length > 0 && obsArray[0]) {
                        var observation = obsArray[0];
                        // Check if the observation has a value entered by the user in the input field
                        if (observation.value) {
                            // Add necessary details if missing (e.g., status, observationDateTime)
                            if (!observation.observationDateTime) {
                                observation.observationDateTime = new Date();
                            }
                            observation.locationUuid = locationUuid; // Ensure location is set if needed by backend
                            observation.encounterUuid = null; // Will be set by backend
                            observation.patientUuid = $scope.patientUuid; // Ensure patientUuid is set

                            observationsToSave.push(observation);
                        }
                    }
                });

                if (observationsToSave.length === 0) {
                    messagingService.showMessage("info", "No new referral details entered to save.");
                    return;
                }

                encounterData.observations = observationsToSave;
                console.log("Data being sent to encounterService.create:", JSON.stringify(encounterData));

                encounterService.create(encounterData).then(function (response) {
                    messagingService.showMessage('info', 'Referral details saved successfully.');
                    ngDialog.close();
                    // Optionally: Broadcast event or reload state if needed
                    $rootScope.$broadcast('event:ipdReferralDataSaved');
                    $state.reload();
                }).catch(function (error) {
                    console.error("Error saving referral data:", error);
                    let errorMessage = 'Failed to save referral data.';
                    if (error.data && error.data.error && error.data.error.message) {
                        errorMessage += ' ' + error.data.error.message;
                    } else if (typeof error === 'string') {
                        errorMessage += ' ' + error;
                    }
                    messagingService.showMessage('error', errorMessage);
                });
            };

            // --- Initialization sequence ---
            var init = function () {
                messagingService.showMessage('info', 'Loading referral details...');
                // Fetch existing data first
                fetchReferralData().then(function () {
                    // Then initialize the concept inputs (needed regardless of fetched data)
                    return initializeConceptInputs();
                }).then(function () {
                    console.log("Initialization complete. Referral data fetched and concept inputs ready.");
                }).catch(function (error) {
                    console.error("Initialization failed:", error);
                    messagingService.showMessage('error', 'Failed to load referral form components.');
                });
            };

            init(); // Run initialization

        }]);